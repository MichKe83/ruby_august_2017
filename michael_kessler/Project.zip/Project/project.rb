class Project
	attr_accessor :name, :description, :owner
	attr_accessor :tasks

	def initialize(name, description)
		@name = name
		@description = description
		@owner = owner
		@tasks = []
	end

	def elevator_pitch
		"#{@name}, #{@description}"
	end

	def print_tasks
		@tasks.each {|x| puts x }
	end

	def add_tasks add_tasks
		@tasks << task
	end
end

project1 = Project.new("Project 1", "Description 1")
p project1.name
p project1.elevator_pitch