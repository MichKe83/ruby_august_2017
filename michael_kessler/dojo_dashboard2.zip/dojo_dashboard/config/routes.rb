Rails.application.routes.draw do
 get "dojos" => "dojos#index"
 get "new" => "dojos#addnew"
 post "create" => "dojos#create"
end
