class DojosController < ApplicationController

	def index

		@dojos = Dojo.all()


		return render 'index.html'
	end

	def addnew


		return render 'addnew.html'
	end

	def create

		Dojo.create(branch: params[:branch], street: params[:street], city: params[:city], state: params[:state])

		return redirect_to '/dojos'
	end

end
