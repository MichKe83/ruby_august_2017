class HelloController < ApplicationController
	def index

		return render text: "Hello Coding Dojo"
	end	

	def say
		return render text: "What do you want me to say???"
	end

	def sayHello
		return render text: "Saying Hello!"

	end

	def sayHelloJoe
		return render text: "Saying Hello Joe!!!!!"
	end

	def sayHelloMichael
		return redirect_to '/say/hello/joe'
	end

	def times
		session[:count] ||= 0
		session[:count] += 1
		puts flash[:notice]
		return render text: "You visited this page: #{session[:count]} times"
	end

	def restart
		session[:count] = nil
				
		flash[:notice] = 'Destroyed stuf!'

		# return	redirect_to '/times'
		return render text: "Destoyed the session!!"
	end

end
