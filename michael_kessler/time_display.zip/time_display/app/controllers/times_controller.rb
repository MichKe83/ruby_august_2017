class TimesController < ApplicationController

	def main
		@time = Time.now
		return render json: @time.strftime('%b %d,%Y - %I:%M:%S')

	end

end
