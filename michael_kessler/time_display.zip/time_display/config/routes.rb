Rails.application.routes.draw do
 
 get '' => 'times#main'
end
