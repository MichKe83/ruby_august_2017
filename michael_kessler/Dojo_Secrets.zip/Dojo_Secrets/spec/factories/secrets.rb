FactoryGirl.define do
  factory :secret do
    context "MyString"
    user nil
  end
end
