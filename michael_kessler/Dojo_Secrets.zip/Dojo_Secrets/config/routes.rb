Rails.application.routes.draw do
  root "users#index"

  get 'register' => 'users#new'
  post 'users' => 'users#create'
  get 'users/:id' => 'users#show'
  patch "users/:id" => "users#update"
  get 'users/:id/edit' => "users#edit"
  delete "users/:id" => "users#destroy"

  get 'secrets/' => 'secrets#index'
  post 'secrets/new' => 'secrets#create'
  delete 'secrets/:id' => 'secrets#destroy'



  get 'login' => 'sessions#new'
  post 'login' => 'sessions#create'
  delete 'logout' => 'sessions#destroy'

end
