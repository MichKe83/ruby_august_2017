Rails.application.routes.draw do
  root "users#index"

  get 'register' => 'users#new'
  post 'users' => 'users#create'
  get 'users/:id' => 'users#show', as: :user
  patch "users/:id" => "users#update"
  get 'users/:id/edit' => "users#edit"
  delete "users/:id" => "users#destroy"

  get 'secrets' => 'secrets#index'
  post 'secrets/new' => 'secrets#create'
  delete 'secrets/:id' => 'secrets#destroy'

  post 'likes/:id' => 'likes#create'
  delete 'likes/:id' => 'likes#destroy'


  get 'login' => 'sessions#new'
  post 'login' => 'sessions#create'
  delete 'logout' => 'sessions#destroy'

end
