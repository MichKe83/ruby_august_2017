class Secret < ActiveRecord::Base
  belongs_to :user
  has_many :likes
  has_many :liked_by, through: :likes, source: :user
  validates :context, presence: true
end
