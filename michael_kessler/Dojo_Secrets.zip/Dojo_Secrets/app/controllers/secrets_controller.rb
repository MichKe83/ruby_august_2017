class SecretsController < ApplicationController
	before_action :require_login, only: [:create, :destroy]

	def index	
		@secrets = Secret.all
	end

	def new
	end

	def create
		user = current_user

		p user 
		p "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		secret = Secret.new(secret_params.merge(user: user))
		p secret.valid?

		if secret.save
			return redirect_to "/users/#{user.id}"
		end

		flash[:errors] = secret.errors.full_messages

	end

	def destroy
		user = session[:user_id]
		secret = Secret.find(params[:id])
		secret.destroy
		return redirect_to "/users/#{user}"
	end

	private
		def secret_params
			params.require(:secret).permit(:context)
		end

		def auth
			return redirect_to user_path(current_user)unless current_user.id == params[:id].to_i
		end


end
