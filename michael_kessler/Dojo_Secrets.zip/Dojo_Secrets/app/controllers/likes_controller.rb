class LikesController < ApplicationController
	before_action :require_login, except: [:index]

	def index
		
	end

	def create
		user = current_user
		secret = Secret.find(params[:id])
		like = Like.new(secret: secret, user: user)
		
		if like.save
			return redirect_to :back
		end
	end

	def destroy
		user = current_user
		secret = Secret.find(params[:id])

		like = Like.find_by(secret: secret, user: user)

		like.destroy

		return redirect_to :back

	end
	private
		def auth
			return redirect_to user_path(current_user)unless current_user.id == params[:id].to_i
		end

end
