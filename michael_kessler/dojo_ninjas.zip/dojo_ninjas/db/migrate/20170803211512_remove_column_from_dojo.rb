class RemoveColumnFromDojo < ActiveRecord::Migration
  def change
    remove_column :dojos, :string, :string
  end
end
