class AddDojoIdToNinjas < ActiveRecord::Migration
  def change
    add_column :ninjas, :dojo, :Integer
  end
end
