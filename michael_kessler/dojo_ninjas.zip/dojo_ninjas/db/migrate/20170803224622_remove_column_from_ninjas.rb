class RemoveColumnFromNinjas < ActiveRecord::Migration
  def change
    remove_column :ninjas, :dojo, :Integer
  end
end
