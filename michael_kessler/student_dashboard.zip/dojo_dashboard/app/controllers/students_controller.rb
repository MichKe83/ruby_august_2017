class StudentsController < ApplicationController

	def addstudent

		@dojos = Dojo.all() 

		return render "addstudent.html"
	end

	def create
		
		Student.create(first_name: params[:first_name], last_name: params[:last_name], email: params[:email], dojo: Dojo.find(params[:dojo_id]))

		return redirect_to '/dojos'
	end

	def show

		@student = Student.find(params[:studentid])
		@dojo = Dojo.find(params[:dojoid])
		@students = @dojo.students.where.not(id: Student.find(params[:studentid]))
		return render 'students/show.html'
	end

	def edit
		@dojos = Dojo.all()
		@student = Student.find(params[:id])

		return render "studentedit.html"

	end

	def update

		student = Student.find(params[:id])

		student.update(first_name: params[:first_name], last_name: params[:last_name], email: params[:email], dojo: Dojo.find(params[:dojo_id]))

		return redirect_to '/dojos'
	end

	def destroy
		@student = Student.find(params[:id])

		@student.destroy
		return redirect_to '/dojos'
	end


end
