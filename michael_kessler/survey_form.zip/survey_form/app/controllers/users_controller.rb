class UsersController < ApplicationController

	def create

		User.create(name: params[:name], location: params[:location], language: params[:language], comment: params[:comments])

		return redirect_to "/result"

	end

	def result

		@users = User.all

		return render "result.html"

	end


end
