Rails.application.routes.draw do
get "" => "users#index"
post "submitsurvey" => "users#create"
get "result" => "users#result"
end
