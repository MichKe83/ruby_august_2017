Rails.application.routes.draw do
 get "dojos" => "dojos#index"
 get "new" => "dojos#addnew"
 post "create" => "dojos#create"
 get "edit/:id" => "dojos#edit"
 get "show/:id" => "dojos#show"
 patch "update/:id" => "dojos#update"
 delete "destroy/:id" => "dojos#destroy"
end
