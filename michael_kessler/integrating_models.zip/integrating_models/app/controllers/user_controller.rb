class UserController < ApplicationController

	def allUsers
		@user = User.all

		return render json: @user
		# return	render 'allUsers.html'

	end

	def newUser


		return render 'newuser.html'
	end

	def user1

		@user1 =  User.find(1)

		return render json: @user1

	end

	def userTotal

		@users = User.all()

		return render 'usertotal.html'
	end

end
