Rails.application.routes.draw do
 get "" => "dojos#index"
end
