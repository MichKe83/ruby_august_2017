class DojosController < ApplicationController

	def index

		@dojos = Dojo.all()


		return render 'index.html'
	end



end
